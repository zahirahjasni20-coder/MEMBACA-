# MEMBACA
Membaca petikan dengan jelas.
